package project;
/*
Create one sigle final Bank object and have a menu to
manage the Bank.
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Main {
    private static Bank bank = new Bank();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice=0;

        while (choice != 8) {
            Menu();
            choice = scanner.nextInt();
            scanner.nextLine();
            if (choice == 1) {
                createAccount(scanner);
            } else if (choice == 2) {
                retrieveAccSSN(scanner);
            } else if (choice == 3) {
                deposit(scanner);
            } else if (choice == 4) {
                withdraw(scanner);
            } else if (choice == 5) {
                payInterest(scanner);
            } else if (choice == 6) {
                checkBalance(scanner);
            } else if (choice == 7) {
                deleteAccount(scanner);
            } else if (choice == 8) {
                System.out.println("Exit");
            } else {
                System.out.println("Try again.");
            }
        }

        scanner.close();
    }
    private static void Menu() {
        System.out.println("Menu: ");
        System.out.println("1. Create an account");
        System.out.println("2. Retrieve an account by SSN");
        System.out.println("3. Deposit");
        System.out.println("4. Withdraw");
        System.out.println("5. Pay interest");
        System.out.println("6. Check balance");
        System.out.println("7. Delete an account");
        System.out.println("8. Exit");
        System.out.print("Enter choice: ");
    }

    private static void createAccount(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountID = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter PIN: ");
        int PIN = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter SSN: ");
        int SSN = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter DOB (YYYY-MM-DD): ");
        LocalDate DOB = LocalDate.parse(scanner.nextLine());

        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        // it creates holders arrays
        Client mainHolder = new Client(SSN, firstName, lastName, DOB, address, new ArrayList<>());
        Client[] holders = { mainHolder };

        System.out.print("Enter initial balance: ");
        double balance = scanner.nextDouble();

        System.out.print("Enter interest rate: ");
        double interestRate = scanner.nextDouble();
        scanner.nextLine();

        // it create the bank account and add it to the bank system
        BankAccount account = new BankAccount(accountID, PIN, holders, mainHolder, balance, LocalDate.now(), LocalDate.now(), interestRate);
        bank.createAccount(account);
        System.out.println("Account was created ");
    }


    private static void retrieveAccSSN(Scanner scanner) {
        System.out.print("Enter SSN: ");
        int SSN = scanner.nextInt();
        scanner.nextLine();

        BankAccount account = bank.retrieveAccSSN(SSN);
        if (account != null) {
            System.out.println("Account was found: " + account);
        } else {
            System.out.println("No account with this SSN: " + SSN);
        }
    }
    private static void deposit(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine();

        // it goes trough all account to find given account num
        Vector<BankAccount> accounts = bank.getBankAccounts();
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount account = accounts.get(i);
            if (account.getAccountID() == accountNumber) {
                System.out.print("Enter amount to deposit: ");
                double amount = scanner.nextDouble();
                scanner.nextLine();
                account.deposit(amount);
                System.out.println("New balance: " + account.getBalance());
                return;
            }
        }
        System.out.println("No account with this account number: " + accountNumber);
    }

    // Method to withdraw money from an account
    private static void withdraw(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine();

        // it goes trough all account to find given account num
        Vector<BankAccount> accounts = bank.getBankAccounts();
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount account = accounts.get(i);
            if (account.getAccountID() == accountNumber) {
                System.out.print("Enter amount to withdraw: ");
                double amount = scanner.nextDouble();
                scanner.nextLine();
                account.withdraw(amount);
                System.out.println("New balance: " + account.getBalance());
                return;
            }
        }
        System.out.println("No account found with account number: " + accountNumber);
    }

    private static void payInterest(Scanner scanner) {
        System.out.print("Enter interest rate: ");
        double interestRate = scanner.nextDouble();
        scanner.nextLine();

        // It goes through bank accounts and pay interest
        Vector<BankAccount> accounts = bank.getBankAccounts();
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount account = accounts.get(i);
            account.payInterest(interestRate);
        }
        System.out.println("Interest paid!");
    }


    private static void checkBalance(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        // it goes through all account to find given account num
        Vector<BankAccount> accounts = bank.getBankAccounts();
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount account = accounts.get(i);
            if (account.getAccountID() == accountNumber) {
                System.out.println("The balance " + accountNumber + " is: " + account.getBalance());
                return;
            }
        }
        System.out.println("No account with this account number: " + accountNumber);
    }


        //it goes  through the accounts to find and delete the account
    private static void deleteAccount(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine();

        bank.deleteAccount(accountNumber);
        System.out.println("Account was deleted ");
    }
}