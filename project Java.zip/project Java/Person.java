package project;


import java.time.LocalDate;
import java.util.Vector;

/*
Class person describing a person
SSN, firstName, lastName, DOB (localDate),
address
List of phone numbers (vector)
 */

//attributes of a person
public class Person {
  private int SSN;
  private String firstName;
  private String lastName;
  private LocalDate DOB;
  private String address;
  private Vector<String> phoneNumbers;


  //constructor
  public Person(int SSN, String firstName, String lastNAme, LocalDate DOB, String address) {
    this.SSN = SSN;
    this.firstName = firstName;
    this.lastName = lastNAme;
    this.DOB = DOB;
    this.address = address;
    this.phoneNumbers = new Vector<>();
  }

  public Person() {

  }

  //getters and setters
  public int getSSN() {

    return SSN;
  }

  public void setSSN(int SSN) {

    this.SSN = SSN;
  }

  public String getFirstName() {

    return firstName;
  }

  public void setFirstName(String firstName) {

    this.firstName = firstName;
  }

  public String getLastName() {

    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public LocalDate getDOB() {

    return DOB;
  }

  public void setDOB(LocalDate DOB) {

    this.DOB = DOB;
  }

  public String getAddress() {

    return address;
  }

  public void setAddress(String address) {

    this.address = address;
  }

  public Vector<String> getPhoneNumbers() {

    return phoneNumbers;
  }

  public void setPhoneNumbers(Vector<String> phoneNumbers) {
    this.phoneNumbers = phoneNumbers;
  }

  @Override
  public String toString() {
    return "Person{" +
            "SSN=" + SSN +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", DOB=" + DOB +
            ", address='" + address + '\'' +
            ", phoneNumbers=" + phoneNumbers +
            '}';
  }
}