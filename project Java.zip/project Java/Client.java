package project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/*
A Client is a Person with A list of Account numbers
 */
public class Client extends Person{
    private List<Integer> accountNumbers;

    //default constructor

    public Client(){
        super();
        this.accountNumbers = new ArrayList<>();
    }
//constructor
    public Client(int SSN, String firstName, String lastNAme, LocalDate DOB, String address, List<Integer> accountNumbers) {
        super(SSN, firstName, lastNAme, DOB, address);
        this.accountNumbers = accountNumbers;
    }

    //getter, setter
    public List<Integer> getAccountNumbers() {
        return accountNumbers;
    }

    public void setAccountNumbers(List<Integer> accountNumbers) {
        this.accountNumbers = accountNumbers;
    }

    @Override
    public String toString() {
        return "Client{" +
                "accountNumbers=" + accountNumbers +
                "} " + super.toString();
    }
}
