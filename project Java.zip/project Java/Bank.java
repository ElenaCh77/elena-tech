package project;

/*
A bank is a collection of BanckAccounts (Vector of bankaccounts)
- Create an account
- Retrieve an account based on SSN, or name or accountNumber
- Update an acount (deposit, withdraw, payInterest, change primary holder
, add holder, change name of holder, change address, phone number ...etc)
- Delete an account.
- List all accounts.
 */


import java.util.Vector;

public class Bank {
    private Vector<BankAccount> bankAccounts;

    public Bank(){
        this.bankAccounts = new Vector<>();
    }

    public Bank(Vector<BankAccount> bankAccounts) {
        this.bankAccounts = bankAccounts;
    }

    //I create an account
    public void createAccount(BankAccount Account){
        bankAccounts.add(Account); // it adds bank account to list of accounts
    }

    //getter, setter
    public Vector<BankAccount> getBankAccounts() {
        return bankAccounts;
    }

    public void setBankAccounts(Vector<BankAccount> bankAccounts) {
        this.bankAccounts = bankAccounts;
    }

    // Retrieve an account based on SSN
    public BankAccount retrieveAccSSN(int SSN) {
        for (int i = 0; i < bankAccounts.size(); i++) { // it goes through all bank accounts
            BankAccount Account = bankAccounts.get(i);  //it gets current bank account
            Client[] holders = Account.getHolders(); //it gets the holder of the current account
            for (int j = 0; j < holders.length; j++) { // it goes through all holders
                if (holders[j].getSSN() == SSN) { //it checks if there is a match of SSN of holder and given SSn
                    return Account; //return account if there is a match
                }
            }
        }
        return null; //if no match of accounts
    }
    //delete an account
    public void deleteAccount(int accountNum){
        for (int i = 0; i < bankAccounts.size(); i++){ //it goes through all bank accounts
            BankAccount Account = bankAccounts.get(i); //it gets current bank account
            if (accountNum == Account.getAccountID()){ //it checks if id match with given account
                bankAccounts.remove(i);  //remove the account from the list
            }
        }
    }
    //List all accounts
    public void listAccounts(){
        for(int i =0; i < bankAccounts.size(); i++){
            System.out.println(bankAccounts.get(i));
        }
    }

}
